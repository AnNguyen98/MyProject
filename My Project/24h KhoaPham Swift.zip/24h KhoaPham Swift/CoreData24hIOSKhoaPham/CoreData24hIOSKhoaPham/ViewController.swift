//
//  ViewController.swift
//  CoreData24hIOSKhoaPham
//
//  Created by An Nguyễn on 3/26/18.
//  Copyright © 2018 An Nguyễn. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPass: UITextField!
    @IBOutlet weak var txtFullName: UITextField!
    @IBAction func check(_ sender: Any) {
        let appDel:AppDelegate = UIApplication.shared.delegate as! AppDelegate
        let context:NSManagedObjectContext = appDel.persistentContainer.viewContext
    
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Class")
        do{
            let results = try context.fetch(request)
            for result in results{
                print((result as AnyObject).value(forKey: "name")!)
            }
        }catch{}
        
    }
    @IBAction func save(_ sender: Any) {
        let appDel:AppDelegate = UIApplication.shared.delegate as! AppDelegate
        let context:NSManagedObjectContext = appDel.persistentContainer.viewContext
        let newName = NSEntityDescription.insertNewObject(forEntityName: "Class", into: context)
        newName.setValue(txtFullName.text!, forKey: "fullName")
        newName.setValue(txtEmail.text!, forKey: "email")
        newName.setValue(txtPass.text!, forKey: "pass")
        newName.setValue(txtName.text!, forKey: "name")
        
        do{
            try context.save()
        }catch{}
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

