//
//  ViewController.swift
//  DoiTuonNSTimer
//
//  Created by An Nguyễn on 3/16/18.
//  Copyright © 2018 An Nguyễn. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var timer:Timer!
    
    @IBOutlet weak var lblHienThi: UILabel!
    @IBAction func startButton(_ sender: Any) {
        var so:Int = Int(lblHienThi.text!)!
        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true, block: { (time) in
            so += 1
            self.lblHienThi.text = String(so)
        })
    }
    
    @IBAction func stopButton(_ sender: Any) {
        timer.invalidate()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

