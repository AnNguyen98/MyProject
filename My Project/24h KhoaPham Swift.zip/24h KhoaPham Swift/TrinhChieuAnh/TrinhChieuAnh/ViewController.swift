//
//  ViewController.swift
//  TrinhChieuAnh
//
//  Created by An Nguyễn on 3/16/18.
//  Copyright © 2018 An Nguyễn. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var arrayHinh:[UIImage] = [#imageLiteral(resourceName: "hinh0"),#imageLiteral(resourceName: "hinh1"),#imageLiteral(resourceName: "hinh2"),#imageLiteral(resourceName: "hinh3"),#imageLiteral(resourceName: "hinh4"),#imageLiteral(resourceName: "hinh5"),#imageLiteral(resourceName: "hinh6"),#imageLiteral(resourceName: "hinh7"),#imageLiteral(resourceName: "hinh8"),#imageLiteral(resourceName: "hinh9"),#imageLiteral(resourceName: "hinh10")]
    var timer:Timer!
    
    @IBOutlet weak var imgHinh: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        var i:Int = 0
        timer = Timer.scheduledTimer(withTimeInterval: 3, repeats: true, block: { (timer) in
            self.imgHinh.image = self.arrayHinh[i]
            i += 1
            if i == self.arrayHinh.count - 1 {
                i = 0
            }
        })
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

