//
//  ViewController.swift
//  ChuyenDongNhanVat
//
//  Created by An Nguyễn on 3/16/18.
//  Copyright © 2018 An Nguyễn. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var timer:Timer!
    var goc = 0.0
    
    @IBOutlet weak var banhXe: UIImageView!
    @IBOutlet weak var start: UIButton!
    @IBOutlet weak var stp: UIButton!
    @IBAction func btnStopBx(_ sender: Any) {
        timer.invalidate()
        stp.isHidden = true
        start.isHidden = false
    }
    @IBAction func btnStart(_ sender: Any) {
        start.isHidden = true
        stp.isHidden = false
        timer = Timer.scheduledTimer(timeInterval: 0.001, target: self, selector: #selector(BanhXe), userInfo: nil, repeats: true)
        
    }
    
    @objc func BanhXe(){
        goc += 5.0
        let gocPi:Double = (Double.pi * goc )/180
        //banhXe.transform.rotated(by: CGFloat(gocPi))
        banhXe.transform = CGAffineTransform(rotationAngle: CGFloat(gocPi))
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        banhXe.layer.cornerRadius = banhXe.bounds.width/2
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

