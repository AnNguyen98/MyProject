//
//  ViewController.swift
//  DonHoDienTu
//
//  Created by An Nguyễn on 3/16/18.
//  Copyright © 2018 An Nguyễn. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var timer:Timer!
    
    @IBOutlet weak var lblMinutes: UILabel!
    @IBOutlet weak var lblSeconds: UILabel!
    @IBOutlet weak var CatTG: UITextView!
    @IBOutlet weak var btnStart: UIButton!
    @IBAction func btnStart(_ sender: Any) {
        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true, block: { (timer) in
            var s:Int = Int(self.lblSeconds.text!)!
            var m:Int = Int(self.lblMinutes.text!)!
            s += 1
            if s >= 60 {
                s = 0
                m += 1
                self.lblMinutes.text = "\(m)"
            }
            self.lblSeconds.text = "\(s)"
        })
    }
    @IBAction func btnStop(_ sender: Any) {
        timer.invalidate()
    }
    var n:Int = 1
    @IBAction func btnCut(_ sender: Any) {
        CatTG.text = CatTG.text! + "Lần \(n) :  \(String(describing: lblMinutes.text!)) : \(String(describing: lblSeconds.text!)) \n"
        n += 1
    }
    @IBAction func btnTGHeThong(_ sender: Any) {
        var tgHeThong:String  = DateFormatter.localizedString(from: Date(), dateStyle: DateFormatter.Style.medium, timeStyle: DateFormatter.Style.short)
        timerLbl.text = tgHeThong
    }
    @IBOutlet weak var timerLbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

