//
//  ViewController.swift
//  PhatSinhBongTuyet
//
//  Created by An Nguyễn on 3/16/18.
//  Copyright © 2018 An Nguyễn. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var btnBongTuyet: UIButton!
    @IBAction func btnBongTuyet(_ sender: Any) {
        var i:Int = 0
        while i <= 100{
            let x:Int = Int(arc4random()) % Int(view.bounds.width)
            let y:Int = Int(arc4random()) % Int(view.bounds.height)
            
            let bongTuyet:UIImageView = UIImageView(frame: CGRect(x: CGFloat(x), y: CGFloat(y), width: 16, height: 16))
            bongTuyet.image = UIImage(named: "BongTuyet")
            view.addSubview(bongTuyet)
            i += 1
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

