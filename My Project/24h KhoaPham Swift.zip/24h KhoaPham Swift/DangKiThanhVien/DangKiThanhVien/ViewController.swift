//
//  ViewController.swift
//  DangKiThanhVien
//
//  Created by An Nguyễn on 3/15/18.
//  Copyright © 2018 An Nguyễn. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtSDT: UITextField!
    @IBOutlet weak var txtHienThi: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func btnXoa(_ sender: Any) {
        txtSDT.text = ""
        txtEmail.text = ""
        txtHienThi.text = ""
        txtName.text = ""
    }
    
    @IBAction func btnDangKi(_ sender: Any) {
        txtHienThi.text = "Họ tên : \(String(describing: txtName.text!))\nEmail : \(String(describing: txtEmail.text!))\nSDT : \(String(describing: txtSDT.text!))"
    }
    @IBOutlet weak var btnXoa: UIButton!
    
}

