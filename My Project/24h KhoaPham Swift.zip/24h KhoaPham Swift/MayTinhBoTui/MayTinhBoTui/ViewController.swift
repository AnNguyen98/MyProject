//
//  ViewController.swift
//  MayTinhBoTui
//
//  Created by An Nguyễn on 3/15/18.
//  Copyright © 2018 An Nguyễn. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var hienThi:String = ""
    var hienThiTruoc:String = ""
    var soThu1:Int!
    var soThu2:Int!
    var ketqua:Int!
    var ketQuaTruoc:Int!
    var dau:String = ""
    @IBOutlet weak var so7: UIButton!
    @IBOutlet weak var so8: UIButton!
    @IBOutlet weak var so9: UIButton!
    @IBOutlet weak var cong: UIButton!
    @IBOutlet weak var lblTinh: UILabel!
    @IBOutlet weak var so4: UIButton!
    @IBOutlet weak var so5: UIButton!
    @IBOutlet weak var so6: UIButton!
    @IBOutlet weak var tru: UIButton!
    @IBOutlet weak var so1: UIButton!
    @IBOutlet weak var so2: UIButton!
    @IBOutlet weak var so3: UIButton!
    @IBOutlet weak var HienThi_KetQua: UITextField!
    @IBAction func so7(_ sender: Any) {
        hienThi += (so7.titleLabel?.text)!
        HienThi_KetQua.text =  hienThiTruoc + hienThi
    }
    @IBAction func so8(_ sender: Any) {
        hienThi += (so8.titleLabel?.text)!
        HienThi_KetQua.text =  hienThiTruoc + hienThi
    }
    @IBAction func so9(_ sender: Any) {
        hienThi += (so9.titleLabel?.text)!
        HienThi_KetQua.text = hienThiTruoc + hienThi
    }
    @IBAction func cong(_ sender: Any) {
        soThu1 = Int(hienThi)
        dau = "cong"
        hienThi += (cong.titleLabel?.text)!
        hienThiTruoc = hienThi
        hienThi = ""
        HienThi_KetQua.text = hienThiTruoc
    }
    @IBAction func so4(_ sender: Any) {
        hienThi += (so4.titleLabel?.text)!
        HienThi_KetQua.text = hienThiTruoc +  hienThi
    }
    @IBAction func so5(_ sender: Any) {
        hienThi += (so5.titleLabel?.text)!
        HienThi_KetQua.text = hienThiTruoc + hienThi
    }
    @IBAction func so6(_ sender: Any) {
        hienThi += (so6.titleLabel?.text)!
        HienThi_KetQua.text = hienThiTruoc + hienThi
    }
    @IBAction func tru(_ sender: Any) {
        soThu1 = Int(hienThi)
        dau = "tru"
        hienThi += (tru.titleLabel?.text)!
        hienThiTruoc = hienThi
        HienThi_KetQua.text = hienThiTruoc
        hienThi = ""
    }
    @IBAction func so1(_ sender: Any) {
        hienThi += (so1.titleLabel?.text)!
        HienThi_KetQua.text =  hienThiTruoc + hienThi
    }
    @IBAction func so2(_ sender: Any) {
        hienThi += (so2.titleLabel?.text)!
        HienThi_KetQua.text =   hienThiTruoc + hienThi
    }
    @IBAction func so3(_ sender: Any) {
        hienThi = (so3.titleLabel?.text)!
        HienThi_KetQua.text =  hienThiTruoc + hienThi
    }
    @IBOutlet weak var nhan: UIButton!
    @IBOutlet weak var clear: UIButton!
    @IBOutlet weak var so0: UIButton!
    @IBOutlet weak var bang: UIButton!
    @IBOutlet weak var chia: UIButton!
    @IBAction func nhan(_ sender: Any) {
        dau = "nhan"
        soThu1 = Int(hienThi)
        hienThi += (nhan.titleLabel?.text)!
        hienThiTruoc = hienThi
        HienThi_KetQua.text = hienThiTruoc
        hienThi = ""
    }
    @IBAction func clear(_ sender: Any) {
        lblTinh.text = ""
        HienThi_KetQua.text = ""
        hienThi = ""
        hienThiTruoc = ""
    }
    @IBAction func so0(_ sender: Any) {
        hienThi += (so0.titleLabel?.text)!
        HienThi_KetQua.text =   hienThiTruoc + hienThi
    }
    @IBAction func bang(_ sender: Any) {
        soThu2 = Int(hienThi)
        switch dau {
        case "cong":
            ketqua = soThu1 + soThu2
            soThu1 = ketqua
        case "tru":
            ketqua = soThu1 - soThu2
            soThu1 = ketqua
        case "chia":
            ketqua = soThu1 / soThu2
            soThu1 = ketqua
        case "nhan":
            ketqua = soThu1 * soThu2
            soThu1 = ketqua
        default:
            break
        }
        lblTinh.text = HienThi_KetQua.text
        HienThi_KetQua.text = String(ketqua)
        hienThi = String(ketqua)
    }
    @IBAction func chia(_ sender: Any) {
        dau = "chia"
        soThu1 = Int(hienThi)
        hienThi += (chia.titleLabel?.text)!
        hienThiTruoc = hienThi
        HienThi_KetQua.text = hienThiTruoc
        hienThi = ""
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

