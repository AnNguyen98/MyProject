//
//  ViewController.swift
//  DieuKhienToaDoBongTrenManHinh
//
//  Created by An Nguyễn on 3/16/18.
//  Copyright © 2018 An Nguyễn. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var imgHinh: UIImageView!
//    var x:CGFloat = 0
//    var y:CGFloat = 0
    @IBAction func btnTop(_ sender: Any) {
//        y -= CGFloat(1)
//        imgHinh.frame = CGRect(x: x, y: y, width: imgHinh.frame.width, height: imgHinh.frame.height)
        imgHinh.frame.origin.y = imgHinh.frame.origin.y - 1
        
    }
    @IBAction func btnLeft(_ sender: Any) {
//        x -= CGFloat(1)
//        imgHinh.frame = CGRect(x: x, y: y, width: imgHinh.frame.width, height: imgHinh.frame.height)
        imgHinh.frame.origin.x = imgHinh.frame.origin.x - 1

    }
    @IBAction func btnDown(_ sender: Any) {
//        y += CGFloat(1)
//        imgHinh.frame = CGRect(x: x, y: y, width: imgHinh.frame.width, height: imgHinh.frame.height)
        imgHinh.frame.origin.y = imgHinh.frame.origin.y + 1

    }
    @IBAction func btnRight(_ sender: Any) {
//        x += CGFloat(1)
//        imgHinh.frame = CGRect(x: x, y: y, width: imgHinh.frame.width, height: imgHinh.frame.height)
        imgHinh.frame.origin.x = imgHinh.frame.origin.x + 1

    }
    @IBOutlet weak var btnRight: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
//        // Do any additional setup after loading the view, typically from a nib.
//        x = imgHinh.frame.origin.x
//        y = imgHinh.frame.origin.y
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

